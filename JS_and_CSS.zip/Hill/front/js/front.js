window.addEventListener('load', function () {
    const createTodoButton = document.querySelector('#todo-button');
    const newTodo = document.querySelector('#todo');
    const todoList = document.querySelector('#todo-list');

    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = () => {
        if (xhr.readyState === 4) {
            const todos = JSON.parse(xhr.response).todos;
            for (let i = 0; i < todos.length; i++) {
                let li = document.createElement('li');
                li.innerText = todos[i];
                todoList.appendChild(li);
            }
        }
    }
    xhr.open("GET", "/api/todos", true);
    xhr.send();


    const toggleBtn = document.querySelector("#toggle-theme");
    const darknessSlider = document.querySelector("#darknessSlider");

    toggleBtn.addEventListener('click', (e) => {
        console.log("Switching theme");
        if (document.documentElement.hasAttribute('theme')) {
            document.documentElement.removeAttribute('theme');
        }
        else {
            document.documentElement.setAttribute('theme', 'dark');
        }
    });
    darknessSlider.addEventListener('change', (e)=>{
        const val = darknessSlider.value
        console.log("Changing darkness", val);
        document.documentElement.style.setProperty('--theme-darkness', val);

    });

    createTodoButton.addEventListener('click', function () {
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "/api/todos", true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.send(JSON.stringify({
            todo: newTodo.value
        }));

        let li = document.createElement('li')
        li.innerText = newTodo.value;
        li.classList.add("clicked-todo");
        todoList.appendChild(li);
        newTodo.value = '';
    });
});
